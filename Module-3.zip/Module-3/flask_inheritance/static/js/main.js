function myfunction(){

    document.getElementById('demo1').innerText ="Hello World"
}